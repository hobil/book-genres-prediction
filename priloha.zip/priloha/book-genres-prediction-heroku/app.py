from flask import Flask, jsonify, render_template, request
import pickle
import gensim
import numpy as np

app = Flask(__name__)

@app.route('/')
def form():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    text = request.form['book']
    tokens = list(gensim.utils.simple_tokenize(text))

    if len(text) < 1600:
        # multinomial naive bayes performed best when trained on long documents
        clf = pickle.load(open('res/mnb_3200_50000.pkl', 'rb'))
        dictionary = pickle.load(open('res/bow_dictionary_3200_50000.pkl', 'rb'))
        corpus = dictionary.doc2bow(tokens)
        x = gensim.matutils.corpus2csc([corpus], num_terms=len(dictionary)).T
    else:
        tfidf = pickle.load(open('res/tfidf_3200_50000.pkl', 'rb'))
        clf = pickle.load(open('res/logreg_tfidf_3200_50000.pkl', 'rb'))
        dictionary = pickle.load(open('res/bow_dictionary_3200_50000.pkl', 'rb'))
        corpus = dictionary.doc2bow(tokens)
        x = gensim.matutils.corpus2csc([tfidf[corpus]], num_terms=len(dictionary)).T

    l = list(zip(clf.predict_proba(x)[0], clf.classes_))
    l = sorted(l, reverse=True)

    res = []
    for score, c in l:
        if score < 0.001:
            break
        res.extend([(c, score.round(3))])

    return render_template('index.html', results=res, text=text)

if __name__ == '__main__':
    mlb2 = pickle.load(open('res/mlb2.pkl', 'rb'))
    app.run(host='0.0.0.0')
